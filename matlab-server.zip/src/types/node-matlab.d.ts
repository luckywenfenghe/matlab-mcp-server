declare module 'node-matlab';
